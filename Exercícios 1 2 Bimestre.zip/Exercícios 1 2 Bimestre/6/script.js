let primeirovalor = document.querySelector ("#primeirovalor")
let segundovalor = document.querySelector ("#segundovalor")
let terceirovalor = document.querySelector ("#terceirovalor")
let quartovalor = document.querySelector ("#quartovalor")
let calcular = document.querySelector ("#calcular")
let Resultado = document.querySelector ("#Resultado")

function passodecalculo(){
    let valorum = Number (primeirovalor.value)
    let valordois = Number (segundovalor.value)
    let valortres = Number (terceirovalor.value)
    let valorquatro = Number (quartovalor.value)

    let menor = valorum
    let posicao = "primeiro"
    
    if (valordois < menor){
        menor = valordois
        posicao = "segundo"
    }

    if (valortres < menor){
        menor = valortres
        posicao = "terceiro"
    }

    if (valorquatro < menor){
        menor = valorquatro
        posicao = "quarto"
    }

    Resultado.textContent = `O ${posicao} numero e o menor`
}
calcular.onclick = function(){
    passodecalculo()
}