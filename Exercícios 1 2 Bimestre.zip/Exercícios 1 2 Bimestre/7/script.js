let numero = document.querySelector ("#numero")
let Resultado = document.querySelector ("#Resultado")
let calculo = document.querySelector ("#calculo")

function calcular (){
    let valor = Number (numero.value)
    if ((valor % 2) == 0){
        Resultado.innerHTML = "O número é <br>✨par✨"
    }

    else {
        Resultado.innerHTML = "O número é <br>✨impar✨"
    }
}

calculo.onclick = function(){
    calcular()
}
