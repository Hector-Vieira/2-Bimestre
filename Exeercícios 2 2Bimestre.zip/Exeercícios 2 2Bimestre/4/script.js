let primeirosabor = document.querySelector ("#primeirosabor")
let segundosabor = document.querySelector ("#segundosabor")
let terceirosabor = document.querySelector ("#terceirosabor")
let quartosabor = document.querySelector ("#quartosabor")
let qtbebida = document.querySelector ("#qtbebida")
let Calcular = document.querySelector ("#Calcular")
let valortotal = document.querySelector ("#valortotal")
let valorrefrigerante = document.querySelector ("#valorrefrigerante")
let valorsabores = document.querySelector ("#valorsabores")


function calculopreco(){
  let saborum =  primeirosabor.value
  let sabordois =  segundosabor.value
  let sabortres =  terceirosabor.value
  let saborquatro =  quartosabor.value
  let bebidas = Number (qtbebida.value)

    

    let valorsab = 0
    if (saborum !=="") {
      valorsab++
    }

    if(sabordois !==""){
      valorsab++
    }
    
    if (sabortres !==""){
      valorsab++
    }
    if (saborquatro !==""){
      valorsab++
    }

    valorsabores.textContent = valorsab * 12

    valorrefrigerante.textContent = bebidas * 7

    valortotal.textContent = (valorsab * 12) + (bebidas * 7)
  }

Calcular.onclick = function (){
    calculopreco()
}