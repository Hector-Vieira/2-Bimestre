let quantidadedepessoas = document.querySelector ("#quantidadedepessoas")
let btcalcular = document.querySelector ("#btcalcular")
let Resultado1 = document.querySelector ("#Resultado1")
let Resultado2 = document.querySelector ("#Resultado2")

function calculo(){
    let numerodepessoas = Number (quantidadedepessoas.value)
    let quantidadequeijo =  numerodepessoas* 50 + " Gramas de queijo"
    let quantidadedeovos =  numerodepessoas* 2 + " ovos"

    Resultado1.textContent = (quantidadedeovos)
    Resultado2.textContent = (quantidadequeijo)
}

btcalcular.onclick = function (){
    calculo()
}


