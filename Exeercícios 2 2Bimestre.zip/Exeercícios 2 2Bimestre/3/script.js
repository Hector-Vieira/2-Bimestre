let primeironumero = document.querySelector ("#primeironumero")
let resultado1 = document.querySelector ("#resultado1")
let segundonumero = document.querySelector ("#segundonumero")
let resultado2 = document.querySelector ("#resultado2")
let resultado3 = document.querySelector ("#resultado3")
let resultado4 = document.querySelector ("#resultado4")
let calcular = document.querySelector ("#calcular")

function calculo (){
    let numeroum = Number (primeironumero.value)
    let numerodois = Number (segundonumero.value)

    resultado1.textContent = "Soma:" + (numeroum + numerodois)
    resultado2.textContent = "Divisao:" + (numeroum / numerodois)
    resultado3.textContent = "Multiplicacao:" + (numeroum * numerodois)
    resultado4.textContent = "Subtracao:" + (numeroum - numerodois)

}

calcular.onclick = function(){
    calculo()
}